python-opencv-detect
====================

webcan capiture and face detect
